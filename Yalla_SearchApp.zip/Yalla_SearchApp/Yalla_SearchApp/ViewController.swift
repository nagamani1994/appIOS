//
//  ViewController.swift
//  Yalla_SearchApp
//
//  Created by student on 3/3/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var resultImage: UIImageView!
    @IBOutlet weak var showNextImages: UIButton!
    @IBOutlet weak var ShowPrevImages: UIButton!
    @IBOutlet weak var topicInfoText: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
    }
    
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
    }
    
    @IBAction func showNextImagesBtn(_ sender: UIButton) {
    }
    

}

